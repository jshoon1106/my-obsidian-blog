![](https://www.youtube.com/watch?v=fpnE6UAfbtU&t=20s)

- 목적: <u>데이터 저장*(Write)*</u>
- latch
    1. <u>SR LATCH</u>: AND, OR
![[image 199.png]]
![[image 200.png]]
![[image 201.png]]
    2. <u>Gated Latch(D Latch)</u>: Write Enable, D —> [레지스터](/348f9f43a08580feacc3d1198d2114cb#348f9f43a08580c3a323d4db93de84f3)
![[image 202.png]]
![[image 203.png]]
![[image 204.png]]
- 레지스터
    1. <u>8-bit Register</u>: Write Enable(1), <u>Data(8)</u>
![[image 205.png]]
    2. 16x16(256) Latch Matrix —> [256-bit Memory](/348f9f43a08580feacc3d1198d2114cb#348f9f43a085805c99cece5dad2f5428)
![[image 206.png]]
        - 필요한 선: <u>35</u>
            - <u>Selection(16+16)</u>, W Enable(1), R Enable(1), <u>Data(1)</u>
        - 주소 지정 방식 개선
            - 목적: 16+16 Selection —> <u>4+4 bit Address</u>
![[image 207.png]]
            - 사용: <u>Multiplexer(1 X 16</u>)
![[image 208.png]]
            - 결과: **256-bit Memory**
                - 필요한 선: <u>**11**</u>
                    - <u>**Adress(4+4)**</u>, W Enable(1), R Enable(1), Data(1)
![[image 209.png]]

RAM

1. <u>**256-byte**</u> Memory
![[image 210.png]]
    - Input: <u>**Adress(8)**</u>, W Enable(1), R Enable(1), <u>**Data(8)**</u>
![[image 211.png]]
![[image 212.png]]
![[image 213.png]]
