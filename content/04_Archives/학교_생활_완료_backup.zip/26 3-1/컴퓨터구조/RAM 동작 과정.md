![](https://www.youtube.com/watch?v=FZGugFqdr60&list=PL8dPuuaLjXtNlUrzyH5r6jN9ulIgZBpdo&index=8)

![[image 214.png]]

![[image 215.png]]

![[image 216.png]]

![[image 217.png]]

![[image 218.png]]

![[image 219.png]]

![[image 220.png]]

![[image 221.png]]